#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include <GL/glew.h> // Added to ensure GLuint is recognized properly

/***********************************************************
// SceneManager
//
// This class contains the code for preparing and rendering
// 3D scenes, including the shader settings.
***********************************************************/
class SceneManager
{
public:
    // Constructor
    SceneManager(ShaderManager* pShaderManager);
    // Destructor
    ~SceneManager();

    // Structure for storing texture information
    struct TEXTURE_INFO
    {
        std::string tag;  // Tag to identify the texture
        GLuint ID;        // OpenGL texture ID (using GLuint for consistency with OpenGL)
    };

    // Structure for storing object material properties
    struct OBJECT_MATERIAL
    {
        glm::vec3 ambientColor;   // Ambient color of the material
        glm::vec3 diffuseColor;   // Diffuse color of the material
        glm::vec3 specularColor;  // Specular color of the material
        float shininess;          // Shininess factor for the material
        std::string tag;          // Tag to identify the material
    };

private:
    ShaderManager* m_pShaderManager;      // Pointer to shader manager object
    ShapeMeshes* m_basicMeshes;           // Pointer to basic shapes object
    int m_loadedTextures;                 // Total number of loaded textures
    TEXTURE_INFO m_textureIDs[16];        // Array for storing loaded textures info
    std::vector<OBJECT_MATERIAL> m_objectMaterials; // Vector for storing defined object materials

    // Method to load texture images and convert them to OpenGL texture data
    bool CreateGLTexture(const char* filename, std::string tag);
    // Method to bind loaded OpenGL textures to texture slots in memory
    void BindGLTextures();
    // Method to free the loaded OpenGL textures from memory
    void DestroyGLTextures();
    // Method to find a loaded texture by its tag
    int FindTextureID(std::string tag);
    // Method to find a defined material by its tag
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);
    // Method to set transformation values (scaling, rotation, translation) into the transform buffer
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);
    // Method to set texture data into the shader based on a given texture tag
    void SetShaderTexture(std::string textureTag);
    // Method to set the material properties into the shader based on a material tag
    void SetShaderMaterial(std::string materialTag);

public:
    // Methods for configuring and rendering the 3D scene
    void PrepareScene();           // Prepare the 3D scene (load objects, textures, materials)
    void RenderScene();            // Render the 3D scene
    void DefineObjectMaterials();  // Define the materials used in the scene
    void SetupSceneLights();       // Set up the lighting for the scene
};
