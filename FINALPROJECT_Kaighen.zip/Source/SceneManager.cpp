///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// =================
// Manages the preparation and rendering of 3D scenes - textures, materials, lighting.
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// Declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_UseLightingName = "bUseLighting";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_ViewPositionName = "viewPosition";
    const char* g_DirectionalLightActive = "directionalLight.bActive";
    const char* g_PointLightActive = "pointLights[0].bActive";
}

/***********************************************************
// Constructor
***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
    m_loadedTextures = 0; // Initialize loaded textures count
}

/***********************************************************
// Destructor
***********************************************************/
SceneManager::~SceneManager()
{
    DestroyGLTextures(); // Clean up loaded textures
    delete m_basicMeshes;
}

/***********************************************************
// CreateGLTexture
***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0, height = 0, colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);
    if (image)
    {
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // Set texture wrapping and filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cerr << "Error: Unsupported image format with " << colorChannels << " channels." << std::endl;
            stbi_image_free(image);
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        std::cout << "Loaded texture: " << filename << " with tag: " << tag << std::endl;
        return true;
    }

    std::cerr << "Error: Could not load image: " << filename << std::endl;
    return false;
}

/***********************************************************
// BindGLTextures
***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
// DestroyGLTextures
***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }
    m_loadedTextures = 0;
}

/***********************************************************
// PrepareScene
***********************************************************/
void SceneManager::PrepareScene()
{
    glEnable(GL_DEPTH_TEST);

    // Load basic shapes
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
    m_basicMeshes->LoadTorusMesh();
    m_basicMeshes->LoadSphereMesh();

    // Load textures
    CreateGLTexture("U:/CS330Content/Projects/4-2_Assignment/textures/wood_texture.jpg", "wood");
    CreateGLTexture("U:/CS330Content/Projects/4-2_Assignment/textures/brick_texture.jpg", "brick");
    CreateGLTexture("U:/CS330Content/Projects/4-2_Assignment/textures/plastic_texture.jpg", "plastic");
    CreateGLTexture("U:/CS330Content/Projects/4-2_Assignment/textures/rubber_texture.jpg", "rubber");
    CreateGLTexture("U:/CS330Content/Projects/4-2_Assignment/textures/fabric_texture.jpg", "fabric");
    CreateGLTexture("U:/CS330Content/Projects/4-2_Assignment/textures/metal_texture.jpg", "metal");

    DefineObjectMaterials();
    SetupSceneLights();
}

/***********************************************************
// RenderScene
***********************************************************/
void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    glm::vec3 positionXYZ;

    // Clear the screen and depth buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Set camera/view position in the shader
    m_pShaderManager->setVec3Value(g_ViewPositionName, 0.0f, 5.0f, 12.0f);

    // *** Render the Desk Surface ***
    scaleXYZ = glm::vec3(10.0f, 0.5f, 5.0f);
    positionXYZ = glm::vec3(0.0f, -0.5f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("wood");
    m_basicMeshes->DrawBoxMesh();

    // *** Render the Monitor Stand ***
    scaleXYZ = glm::vec3(0.1f, 1.0f, 0.1f);
    positionXYZ = glm::vec3(0.0f, -0.2f, -2.5f); // Lower the stand position slightly
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("plastic");
    m_basicMeshes->DrawCylinderMesh();

    // *** Render the Monitor Screen ***
    scaleXYZ = glm::vec3(3.0f, 1.5f, 0.1f);
    positionXYZ = glm::vec3(0.0f, 1.2f, -2.5f); // Lower the monitor screen slightly
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("plastic");
    m_basicMeshes->DrawBoxMesh();

    // *** Render the Keyboard ***
    scaleXYZ = glm::vec3(5.0f, 0.2f, 1.5f);
    positionXYZ = glm::vec3(0.0f, -0.3f, -1.5f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("plastic");
    m_basicMeshes->DrawBoxMesh();

    // *** Render the Mouse ***
    scaleXYZ = glm::vec3(0.5f, 0.2f, 0.7f); // Reduced scale for a smaller mouse
    positionXYZ = glm::vec3(3.0f, -0.3f, -1.5f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("rubber");
    m_basicMeshes->DrawTaperedCylinderMesh();

    // *** Render the Mouse Scroll Wheel ***
    scaleXYZ = glm::vec3(0.1f, 0.1f, 0.1f); // Scaled down to match the mouse size
    positionXYZ = glm::vec3(3.0f, -0.15f, -1.5f); // Adjusted position slightly to fit on the smaller mouse
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("plastic");
    m_basicMeshes->DrawSphereMesh();

    // *** Render the Headset Ear Cup (Left) ***
    scaleXYZ = glm::vec3(0.5f, 0.5f, 0.2f);
    positionXYZ = glm::vec3(-4.0f, -0.1f, 1.5f); // Position on the desk, left side
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("fabric");
    m_basicMeshes->DrawCylinderMesh();

    // *** Render the Headset Ear Cup (Right) ***
    positionXYZ = glm::vec3(-4.0f, -0.1f, 1.0f); // Adjust position for the right ear cup
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("fabric");
    m_basicMeshes->DrawCylinderMesh();

    // *** Render the Headset Band ***
    scaleXYZ = glm::vec3(1.2f, 0.2f, 1.2f);
    positionXYZ = glm::vec3(-4.0f, 0.3f, 1.25f); // Positioned above the ear cups on the desk
    SetTransformations(scaleXYZ, 0.0f, 90.0f, 0.0f, positionXYZ); // Rotate to align as the band
    SetShaderMaterial("fabric");
    m_basicMeshes->DrawTorusMesh();
}


/***********************************************************
// SetShaderTexture
***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    int textureID = FindTextureID(textureTag);
    if (textureID != -1)
    {
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, textureID);
        m_pShaderManager->setIntValue("objectTexture", 0);
    }
    else
    {
        std::cerr << "Error: Texture with tag '" << textureTag << "' not found." << std::endl;
    }
}

/***********************************************************
// SetShaderMaterial
//
// This method sets the material properties (ambient, diffuse, specular colors, and shininess)
// for the shader based on a given material tag.
***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    OBJECT_MATERIAL material;
    // Find the material based on the tag
    if (FindMaterial(materialTag, material))
    {
        // Set the material's ambient, diffuse, and specular properties in the shader
        m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
        m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", material.shininess);

        // Set whether to use textures based on the material tag
        if (FindTextureID(materialTag) != -1)
        {
            m_pShaderManager->setBoolValue(g_UseTextureName, true);
            SetShaderTexture(materialTag);
        }
        else
        {
            m_pShaderManager->setBoolValue(g_UseTextureName, false);
        }

        // Debug output
        std::cout << "Material set: " << materialTag << std::endl;
    }
    else
    {
        std::cerr << "Error: Material with tag '" << materialTag << "' not found." << std::endl;
    }
}


/***********************************************************
// FindTextureID
***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag == tag)
        {
            return m_textureIDs[i].ID;
        }
    }
    return -1;
}

/***********************************************************
// FindMaterial
***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    for (const auto& mat : m_objectMaterials)
    {
        if (mat.tag == tag)
        {
            material = mat;
            return true;
        }
    }
    return false;
}

/***********************************************************
// DefineObjectMaterials
***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    // Define wood material
    OBJECT_MATERIAL woodMaterial;
    woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
    woodMaterial.diffuseColor = glm::vec3(0.6f, 0.4f, 0.2f);
    woodMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
    woodMaterial.shininess = 32.0f;
    woodMaterial.tag = "wood";
    m_objectMaterials.push_back(woodMaterial);

    // Define plastic material
    OBJECT_MATERIAL plasticMaterial;
    plasticMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
    plasticMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
    plasticMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.7f);
    plasticMaterial.shininess = 50.0f;
    plasticMaterial.tag = "plastic";
    m_objectMaterials.push_back(plasticMaterial);

    // Define rubber material
    OBJECT_MATERIAL rubberMaterial;
    rubberMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
    rubberMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
    rubberMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
    rubberMaterial.shininess = 10.0f;
    rubberMaterial.tag = "rubber";
    m_objectMaterials.push_back(rubberMaterial);

    // Define metal material
    OBJECT_MATERIAL metalMaterial;
    metalMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
    metalMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
    metalMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
    metalMaterial.shininess = 75.0f;
    metalMaterial.tag = "metal";
    m_objectMaterials.push_back(metalMaterial);

    // Define fabric material
    OBJECT_MATERIAL fabricMaterial;
    fabricMaterial.ambientColor = glm::vec3(0.3f, 0.2f, 0.3f);
    fabricMaterial.diffuseColor = glm::vec3(0.5f, 0.4f, 0.5f);
    fabricMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
    fabricMaterial.shininess = 20.0f;
    fabricMaterial.tag = "fabric";
    m_objectMaterials.push_back(fabricMaterial);

    // Define brick material
    OBJECT_MATERIAL brickMaterial;
    brickMaterial.ambientColor = glm::vec3(0.4f, 0.2f, 0.2f);
    brickMaterial.diffuseColor = glm::vec3(0.8f, 0.4f, 0.4f);
    brickMaterial.specularColor = glm::vec3(0.3f, 0.2f, 0.2f);
    brickMaterial.shininess = 15.0f;
    brickMaterial.tag = "brick";
    m_objectMaterials.push_back(brickMaterial);
}


/***********************************************************
// SetupSceneLights
***********************************************************/
void SceneManager::SetupSceneLights()
{
    // Set the direction for the directional light (pointing downwards and slightly to the left)
    m_pShaderManager->setVec3Value("directionalLight.direction", -0.5f, -1.0f, -0.3f);

    // Set ambient, diffuse, and specular properties for the directional light
    m_pShaderManager->setVec3Value("directionalLight.ambient", 0.5f, 0.5f, 0.5f);
    m_pShaderManager->setVec3Value("directionalLight.diffuse", 1.0f, 1.0f, 1.0f);
    m_pShaderManager->setVec3Value("directionalLight.specular", 1.0f, 1.0f, 1.0f);


    // Activate the directional light
    m_pShaderManager->setBoolValue(g_DirectionalLightActive, true);
}


/***********************************************************
// SetTransformations
***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 modelView;
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    // Combine the transformations: translation * rotationZ * rotationY * rotationX * scale
    modelView = translation * rotationZ * rotationY * rotationX * scale;

    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

