///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// Manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Colyn Kaighen (based on template by Brian Battersby - SNHU Instructor)
//  Created for CS-330-Computational Graphics and Visualization, 2023.
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// Global variables for viewport management
namespace
{
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;
    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    // Camera for controlling scene viewing
    Camera* g_pCamera = nullptr;

    // Variables for mouse movement processing
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // Time tracking for smooth motion
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // Orthographic projection toggle (if needed)
    bool bOrthographicProjection = false;
}

/***********************************************************
 *  ViewManager()
 *  Constructor for the ViewManager class
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = NULL;
    g_pCamera = new Camera();

    // Set initial camera position and parameters
    g_pCamera->Position = glm::vec3(0.5f, 5.5f, 10.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 80;
    g_pCamera->MovementSpeed = 10;
}

/***********************************************************
 *  ~ViewManager()
 *  Destructor for ViewManager class
 ***********************************************************/
ViewManager::~ViewManager()
{
    m_pShaderManager = NULL;
    m_pWindow = NULL;
    if (g_pCamera != nullptr)
    {
        delete g_pCamera;
        g_pCamera = nullptr;
    }
}

/***********************************************************
 *  CreateDisplayWindow()
 *  Method for creating the OpenGL display window
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
    if (!window)
    {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return nullptr;
    }
    glfwMakeContextCurrent(window);

    // Setup callbacks for mouse movement and scrolling
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
    glfwSetScrollCallback(window, &ViewManager::Scroll_Callback);

    // Enable mouse input mode for camera control
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Enable blending for transparency
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *  Automatically triggered when mouse moves
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
    if (gFirstMouse)
    {
        gLastX = xMousePos;
        gLastY = yMousePos;
        gFirstMouse = false;
    }

    // Calculate offsets based on previous position
    float xOffset = xMousePos - gLastX;
    float yOffset = gLastY - yMousePos;

    gLastX = xMousePos;
    gLastY = yMousePos;

    // Adjust camera orientation based on mouse movement
    g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Scroll_Callback()
 *  Adjusts camera movement speed with mouse scroll
 ***********************************************************/
void ViewManager::Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
    // Adjust the camera's movement speed based on scroll input
    g_pCamera->MovementSpeed += yOffset * 0.5f;  // Increase or decrease speed
    // Ensure the speed remains within reasonable bounds
    if (g_pCamera->MovementSpeed < 1.0f) g_pCamera->MovementSpeed = 1.0f;
    if (g_pCamera->MovementSpeed > 50.0f) g_pCamera->MovementSpeed = 50.0f;
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *  Handles keyboard inputs for camera movement
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
    // Close the window if the Escape key is pressed
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(m_pWindow, true);
    }

    if (!g_pCamera) return;

    // Zoom in/out with W and S keys
    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    }
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    }

    // Pan left and right with A and D keys
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    }
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
    }

    // Move up and down using Q and E keys
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(UP, gDeltaTime);  // Use UP
    }
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);  // Use DOWN
    }
}

/***********************************************************
 *  PrepareSceneView()
 *  Setup the view matrix and projection matrix for rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
    float currentFrame = glfwGetTime();
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    // Process keyboard events for each frame
    ProcessKeyboardEvents();

    // Get the view matrix from the camera and set up the projection matrix
    glm::mat4 view = g_pCamera->GetViewMatrix();
    glm::mat4 projection = glm::perspective(glm::radians(g_pCamera->Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Apply the matrices to the shaders
    if (m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}
